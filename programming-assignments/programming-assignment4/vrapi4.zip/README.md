# Programming Assignment 3

## Running The project

This project uses `python3`. Running `python3 signal.py` will run the program. At the bottom of that file you will find calls that run the test cases that produce the output used in the analysis portion of the write-up.

Finally, the file `test-cases.txt` contains the output from running the program.

## List of Files

1. signal.py
2. signal.cover
3. test-cases.txt
4. ProgrammingAssignment4.pdf
5. README.md

All `.cover` files are trace files. All `.py` files are code files. The `.pdf` file is my compiled latex for this assignment.
